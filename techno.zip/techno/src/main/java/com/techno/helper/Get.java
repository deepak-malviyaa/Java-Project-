package com.techno.helper;

import java.sql.Connection;

public class Get {

	public static void main(String[] args) {
	new Get();
	}// TODO Auto-generated method stub
		Get(){
		Connection con;
		con=ConnectionProvider.getConnection();
		System.out.println(con);
	}
	
}
