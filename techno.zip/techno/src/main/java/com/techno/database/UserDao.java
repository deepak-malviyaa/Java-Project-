package com.techno.database;
import java.sql.*;

import com.techno.entities.User;
public class UserDao {
	private Connection con;

	public UserDao(Connection con) {
//		super();
		this.con = con;
	}
	public boolean saveUser(User user) {
		boolean f=false;
		try {

			String query="insert into user(name,email,password,gender,about) values(?,?,?,?,?)";
			PreparedStatement ps=this.con.prepareStatement(query);
			ps.setString(1,user.getName());
			ps.setString(2,user.getEmail());
			ps.setString(3,user.getPassword());
			ps.setString(4,user.getGender());
			ps.setString(5,user.getAbout());
			
			ps.executeUpdate();
			f=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	public User getUserByEmailAndPasword(String email,String password) {
	User user=null;
	
	try {
		
		String query="select * from user where email=? and password=? ";
		PreparedStatement psmt=con.prepareStatement(query);
		psmt.setString(1,email);
		psmt.setString(2,password);
		
		ResultSet rs=psmt.executeQuery();
		
		if(rs.next()) {
			user=new User();
			String name=rs.getString("name");
			user.setName(name);
			user.setId(rs.getInt("id"));
			user.setEmail(rs.getString("email"));
			user.setPassword(rs.getString("password"));
			user.setGender(rs.getString("gender"));
			user.setAbout(rs.getString("about"));
			user.setDateTime(rs.getTimestamp("rdate"));
			user.setProfile(rs.getString("profile"));
		}
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	return user;
	}
	
	public boolean updateUser(User user) {
		boolean f=false;
		try {
			String query="update user set name=? ,email=?,password=?,gender=?,about=?,profile=? where id=?";
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, user.getName());
			psmt.setString(2, user.getEmail());
			psmt.setString(3, user.getPassword());
//			psmt.setString(4, user.get());
			psmt.setString(4, user.getGender());
			psmt.setString(5, user.getAbout());
			psmt.setString(6, user.getProfile());
			psmt.setInt(7,user.getId());
			psmt.executeUpdate();
			f=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
	return f;
	}

	public User getUserByUserId(int userId) {
		User user=null;
		try{
			String q="select * from user where Id=?";
			PreparedStatement p=this.con.prepareStatement(q);
			p.setInt(1,userId);
			ResultSet set=p.executeQuery();
			if(set.next()) {
				user=new User();
				String name=set.getString("name");
				user.setName(name);
				user.setId(set.getInt("id"));
				user.setEmail(set.getString("email"));
				user.setPassword(set.getString("password"));
				user.setGender(set.getString("gender"));
				user.setAbout(set.getString("about"));
				user.setDateTime(set.getTimestamp("rdate"));
				user.setProfile(set.getString("profile"));	
				
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		
		return user;
	} 

}
