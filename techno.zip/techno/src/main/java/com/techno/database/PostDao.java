package com.techno.database;
import java.sql.*;
import java.util.ArrayList;
//import java.util.Locale.Category;
import java.util.List;

import com.techno.entities.categories;
import com.techno.entities.post;
public class PostDao {
	Connection con;

	public PostDao(Connection con) {
		this.con = con;
	}
	public ArrayList<categories> getAllCategories(){
		ArrayList<categories>list=new ArrayList<>();
	
		try {
			String q="select * from categories";
			Statement st=this.con.createStatement();
			ResultSet set=st.executeQuery(q);
			while(set.next()) {
				int cid=set.getInt("cid");
				String name=set.getString("name");
				String description=set.getString("description");
				categories c= new categories(cid,name,description);
				list.add(c);
			}
		} catch (Exception e) {
		e.printStackTrace();
		}
		
		
		return list;
	}
	
	public boolean savePost(post p) {
		boolean f=false;
		try {
		
			String q="insert into post(pTitle,pContent,pCode,pPic,catId,userId)values(?,?,?,?,?,?)";
			PreparedStatement psmt=con.prepareStatement(q);
			psmt.setString(1,p.getpTitle());
			psmt.setString(2,p.getpContent());
			psmt.setString(3,p.getpCode());
			psmt.setString(4,p.getpPic());
			psmt.setInt(5,p.getCatId());
			psmt.setInt(6,p.getUserId());
			psmt.executeUpdate();
			f=true;
		    } catch (Exception e) {
			e.printStackTrace();
		}
		return f;	
	}
	
	public List<post>getAllPosts(){
		List<post>list=new ArrayList<>();
		try {
			PreparedStatement p=con.prepareStatement("select * from post");
			ResultSet set=p.executeQuery();
			while (set.next()) {
				int pid=set.getInt("pId");
				String pTitle=set.getString("pTitle");
				String pContent=set.getString("pContent");
				String pCode=set.getString("pCode");
				String pPic=set.getString("pPic");
				Timestamp date=set.getTimestamp("pDate");
				int catId=set.getInt("catId");
				int userId=set.getInt("userId");
				post p1=new post(pid, pTitle, pContent, pCode, pPic, date, catId, userId);
				
				list.add(p1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public List<post> getPostBycatId(int catId){
		List<post>list=new ArrayList<>();
		try {
			PreparedStatement p=con.prepareStatement("select * from post where catId=?");
			p.setInt(1, catId);
			ResultSet set=p.executeQuery();
			while (set.next()) {
				int pid=set.getInt("pId");
				String pTitle=set.getString("pTitle");
				String pContent=set.getString("pContent");
				String pCode=set.getString("pCode");
				String pPic=set.getString("pPic");
				Timestamp date=set.getTimestamp("pDate");
//				int catId=set.getInt("catId");
				int userId=set.getInt("userId");
				post p1=new post(pid, pTitle, pContent, pCode, pPic, null, catId, userId);
				list.add(p1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public post getPostByPostId(int postId) {
		post post1=null;
		String q="select * from post where pId=?";
		try {
		PreparedStatement p=this.con.prepareStatement(q);
		p.setInt(1,postId);
		ResultSet set=p.executeQuery();
		if(set.next()) {
			int pid=set.getInt("pId");
			String pTitle=set.getString("pTitle");
			String pContent=set.getString("pContent");
			String pCode=set.getString("pCode");
			String pPic=set.getString("pPic");
			Timestamp date=set.getTimestamp("pDate");
			int catId=set.getInt("catId");
			int userId=set.getInt("userId");
			post1=new post(pid, pTitle, pContent, pCode, pPic, date, catId, userId);
			
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return post1;
		
	}
}
