package com.techno.entities;

public class categories {
	private int cid;
	private String name; 
	private String descripation;
	public categories(int cid, String name, String descripation) {
		this.cid = cid;
		this.name = name;
		this.descripation = descripation;
	}
	public categories() {
	}
	public categories(String name, String descripation) {
		this.name = name;
		this.descripation = descripation;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescripation() {
		return descripation;
	}
	public void setDescripation(String descripation) {
		this.descripation = descripation;
	}
	
}
