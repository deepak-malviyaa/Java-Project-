package com.techno.servlet;

import java.io.IOException;
//import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import com.mysql.cj.protocol.Message;
import com.techno.database.UserDao;
import com.techno.entities.User;
import com.techno.helper.ConnectionProvider;
import com.techno.entities.*;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		PrintWriter pw=response.getWriter();
//		response.setContentType("text/html");
		String userEmail=request.getParameter("email");
		String userPassword=request.getParameter("password");
		
		UserDao dao=new UserDao(ConnectionProvider.getConnection());
		User u=dao.getUserByEmailAndPasword(userEmail, userPassword);
		if(u==null) {
//			pw.println("Invalid Details ..try again..");
			Message msg=new Message("invalid deatils try with another","error","alert-danger");
			HttpSession s=request.getSession();
			s.setAttribute("msg",msg);
			
			response.sendRedirect("login_page.jsp");
		}else {
			
			HttpSession s=request.getSession();
			s.setAttribute("currentUser", u);
			response.sendRedirect("profile.jsp");
			
			
		}
		
	}

}
